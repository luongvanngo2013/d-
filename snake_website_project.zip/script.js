const cv=document.getElementById('game'),ctx=cv.getContext('2d');
const G=24,C=25;
let snake,dir,food,score,level,goal,speed,over;
function rf(){while(true){let f={x:Math.floor(Math.random()*C),y:Math.floor(Math.random()*C)};
if(!snake.some(s=>s.x===f.x&&s.y===f.y))return f;}}
function hud(){scoreEl.textContent=score;levelEl.textContent=level;goalEl.textContent=goal;}
const scoreEl=document.getElementById('score'),levelEl=document.getElementById('level'),goalEl=document.getElementById('goal');
function reset(){snake=[{x:5,y:5}];dir={x:1,y:0};score=0;level=1;goal=5;speed=140;over=false;food=rf();hud();}
reset();
document.addEventListener('keydown',e=>{
if(over&&e.code==='Space'){reset();return;}
if(e.key==='ArrowUp'&&dir.y!==1)dir={x:0,y:-1};
if(e.key==='ArrowDown'&&dir.y!==-1)dir={x:0,y:1};
if(e.key==='ArrowLeft'&&dir.x!==1)dir={x:-1,y:0};
if(e.key==='ArrowRight'&&dir.x!==-1)dir={x:1,y:0};
});
function draw(){
ctx.fillStyle='#102030';ctx.fillRect(0,0,600,600);
ctx.fillStyle='red';ctx.beginPath();ctx.arc(food.x*G+12,food.y*G+12,9,0,Math.PI*2);ctx.fill();
snake.forEach((s,i)=>{ctx.fillStyle=i?'#2f2':'#9f9';ctx.fillRect(s.x*G+2,s.y*G+2,20,20);});
if(over){ctx.fillStyle='white';ctx.font='28px Arial';ctx.fillText('Game Over - Space',150,300);}
}
function tick(){
if(!over){
let h={x:snake[0].x+dir.x,y:snake[0].y+dir.y};
if(h.x<0||h.y<0||h.x>=C||h.y>=C||snake.some(s=>s.x===h.x&&s.y===h.y))over=true;
else{
snake.unshift(h);
if(h.x===food.x&&h.y===food.y){score++;if(score>=goal){level++;goal+=5;speed=Math.max(60,speed-10);}food=rf();hud();}
else snake.pop();
}}
draw();setTimeout(tick,speed);}
tick();
